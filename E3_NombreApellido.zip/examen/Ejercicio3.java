package examen;
/**
 * Sirve para que solicite una frase al usuario, introduzca las palabras en un array,
 * y las muestra ordenadas de manera descendente (Z-A)
 */
import java.util.Arrays;
import java.util.Scanner;
public class Ejercicio3 {
	
	
	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Ponga una frase: ");
	        String frase = scanner.nextLine();

	        String[] palabras = frase.split(" ");
	        Arrays.sort(palabras, java.util.Collections.reverseOrder());

	        System.out.println("Frases ordenadas descendente:");
	        for (String texto : palabras) {
	            System.out.println(texto);
	        }
	    }
	}


