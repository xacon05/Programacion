package examen;
/**
 * Sirve para que una tabla de números naturales según el tamaño indicado por el usuario,
 * y encuentra la posición del número más grande.
 */
import java.util.Scanner;
public class Ejercicio2 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Introduce el tamaño de la tabla: ");
	        int tamaño = scanner.nextInt();

	        int[] tabla = new int[tamaño];
	        System.out.println("Introduce los números naturales:");
	        for (int i = 0; i < tamaño; i++) {
	            tabla[i] = scanner.nextInt();
	        }

	        int maxPos = 0;
	        for (int i = 1; i < tamaño; i++) {
	            if (tabla[i] > tabla[maxPos]) {
	                maxPos = i;
	            }
	            //grwerewr//
	      
	        }
	        System.out.println("La posición del número más grande es: " + maxPos);
	    }
	}



