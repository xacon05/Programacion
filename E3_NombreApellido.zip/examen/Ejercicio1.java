package examen;
/**
Sirve para crear un array de números enteros, que imprima su referencia y contenido,y calcula la suma de los elementos en posiciones impares.
*/
public class Ejercicio1 {

	    public static void main(String[] args) {
	        int[] numeros = {12, 15, 17, 21, 23, 28, 31, 35, 41, 51};
	        System.out.println("Referencia del array: " + numeros);
	        System.out.println("Contenido del array: " + java.util.Arrays.toString(numeros));

	        int sumaImpares = 0;
	        for (int i = 1; i < numeros.length; i += 2) {
	            sumaImpares += numeros[i];
	        }
	        System.out.println("Suma de elementos en posiciones impares: " + sumaImpares);
	    }
	}

