package examen;

public class Ejercicio4 {
	String[][] tabla = {
			{"Diego","Bicicleta","Puerto serrano"},
			{"Juan","Play 5", "El Bosque"},
			{"Carlos","Pc", "Ubrique"},
			{"Antonio", "sudadera", "Prado del rey"},
			{"Sara", "Helicoptero telederigido","Sevilla"}
	};
	
			
}
