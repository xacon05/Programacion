package tema4;

public class ContadorObjetos {

}
