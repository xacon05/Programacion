package tema4;

public class ContadorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
