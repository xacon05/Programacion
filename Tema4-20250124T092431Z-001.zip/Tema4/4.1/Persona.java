package tema4;

public class Persona {

}
